"""
SynthTIGER
Copyright (c) 2021-present NAVER Corp.
MIT license
"""

from synthtiger.components.font.base_font import BaseFont

__all__ = ["BaseFont"]
