Color components
================

.. automodule:: synthtiger.components.color
   :members:
   :undoc-members:
