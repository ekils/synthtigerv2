Layout components
=================

.. automodule:: synthtiger.components.layout
   :members:
   :undoc-members:
