Text effect components
======================

.. automodule:: synthtiger.components.text_effect
   :members:
   :undoc-members:
