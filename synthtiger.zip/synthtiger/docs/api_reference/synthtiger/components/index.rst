Components
==========

.. automodule:: synthtiger.components
   :members:
   :undoc-members:

.. toctree::
   :maxdepth: 2

   component
   corpus
   font
   texture
   layout
   transform
   color
   text_effect
   image_effect
   wrapper
