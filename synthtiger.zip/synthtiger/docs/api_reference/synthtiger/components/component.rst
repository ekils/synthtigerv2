Base component
==============

.. automodule:: synthtiger.components.component
   :members:
   :undoc-members:
