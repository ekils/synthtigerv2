File util
=========

.. automodule:: synthtiger.utils.file_util
   :members:
   :undoc-members:
