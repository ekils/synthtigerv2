SynthTIGER
==========

.. automodule:: synthtiger
   :members:
   :undoc-members:

.. toctree::
   components/index
   layers/index
   templates/index
   utils/index
