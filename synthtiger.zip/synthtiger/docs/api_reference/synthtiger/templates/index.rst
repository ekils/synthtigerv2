Templates
=========

.. automodule:: synthtiger.templates
   :members:
   :undoc-members:
