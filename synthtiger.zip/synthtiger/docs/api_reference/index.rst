API Reference
=============

.. toctree::
   synthtiger/index
