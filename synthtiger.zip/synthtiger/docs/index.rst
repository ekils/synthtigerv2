SynthTIGER
==========

SynthTIGER is synthetic text image generator for OCR model.

.. image:: https://user-images.githubusercontent.com/12423224/153699080-29da7908-0662-4435-ba27-dd07c3bbb7f2.png
   :align: center

.. toctree::
   api_reference/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
